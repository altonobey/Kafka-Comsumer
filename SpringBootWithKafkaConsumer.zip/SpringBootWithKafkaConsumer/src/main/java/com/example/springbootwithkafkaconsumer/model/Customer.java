package com.example.springbootwithkafkaconsumer.model;

import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Customer {

    private String firstName;
    private String lastName;
    private String emailAddress;
    private String phoneNumber;

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer();
        sb.append("First Name: ").append(firstName);
        sb.append(", Last Name: ").append(lastName);
        sb.append(", Email Address: ").append(emailAddress);
        sb.append(", Phone Number: ").append(phoneNumber);
        return sb.toString();
    }
}

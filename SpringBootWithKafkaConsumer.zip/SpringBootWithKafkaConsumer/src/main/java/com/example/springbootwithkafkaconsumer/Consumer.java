package com.example.springbootwithkafkaconsumer;

import com.example.springbootwithkafkaconsumer.model.Customer;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.KafkaListener;

@Configuration
public class Consumer {

    @KafkaListener(topics = "Kafka_Example", groupId = "group_id")
    public void consumeMessageString(String message) { System.out.println("Consumed String Message: " + message); }

    @KafkaListener(topics = "Kafka_Example_Json", groupId = "group_json",
            containerFactory = "customerKafkaListenerFactory")
    public void consumeMessageJson(Customer customer) { System.out.println("Consumed JSON Message: " + customer.toString()); }
}

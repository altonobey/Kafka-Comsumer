package com.example.springbootwithkafkaconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWithKafkaConsumerApplicationTests {

    @Test
    void contextLoads() {
    }

}
